<?php
return [
    'categories' => [
        'container' => 'Container',
        // 'tanker' => 'Tanktainer',
        'vehicle' => 'Vahicle',
        'unit' => 'Unit',
        'package' => 'Package',
        'general_set' => 'General Set',
        'other' => 'Other'
    ]
];
