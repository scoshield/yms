<?php

return [
    'site_title' => 'YardMS',
];
